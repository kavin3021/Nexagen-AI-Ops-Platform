from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os
from typing import Optional
import uvicorn

app = FastAPI(title="NexaGen AI Multi-Cloud Platform", version="1.0.0")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic models
class MultimodalRequest(BaseModel):
    provider: str = "azure"  # "azure" or "gcp"
    task: str = "10k"  # "10k" or "cricket"
    text: str
    image_uri: Optional[str] = None
    table_data: Optional[str] = None

class AnalysisResponse(BaseModel):
    provider: str
    task: str
    text_analysis: str
    image_analysis: Optional[str] = None
    combined_summary: str

@app.get("/")
async def root():
    return {"message": "NexaGen AI Multi-Cloud Platform", "status": "running"}

@app.get("/health")
async def health():
    return {
        "status": "healthy", 
        "azure_configured": bool(os.getenv("AZURE_OPENAI_ENDPOINT")),
        "gcp_10k_configured": bool(os.getenv("GCP_GEMINI_10K_ENDPOINT")),
        "gcp_cricket_configured": bool(os.getenv("GCP_GEMINI_CRICKET_ENDPOINT"))
    }

@app.post("/analyze-text", response_model=AnalysisResponse)
async def analyze_text(request: MultimodalRequest):
    try:
        if request.provider == "azure":
            from services.azure_service import analyze_text_azure
            result = analyze_text_azure(request.text)
        else:
            from services.gcp_service import analyze_text_gcp
            result = analyze_text_gcp(request.text, request.task)
        
        return AnalysisResponse(
            provider=request.provider,
            task=request.task,
            text_analysis=result,
            combined_summary=f"Analysis from {request.provider} ({request.task}): {result[:200]}..."
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/analyze-multimodal", response_model=AnalysisResponse)
async def analyze_multimodal(request: MultimodalRequest):
    try:
        if request.provider == "azure":
            from services.azure_service import analyze_multimodal_azure
            text_result, image_result = analyze_multimodal_azure(request.text, request.image_uri)
        else:
            from services.gcp_service import analyze_multimodal_gcp
            text_result, image_result = analyze_multimodal_gcp(request.text, request.image_uri, request.task)
        
        combined = f"Text: {text_result}. Image: {image_result}" if image_result else text_result
        
        return AnalysisResponse(
            provider=request.provider,
            task=request.task,
            text_analysis=text_result,
            image_analysis=image_result,
            combined_summary=combined
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/analyze-cricket", response_model=AnalysisResponse)
async def analyze_cricket(request: MultimodalRequest):
    """Dedicated endpoint for cricket player analysis"""
    request.task = "cricket"
    return await analyze_multimodal(request)

@app.post("/analyze-10k", response_model=AnalysisResponse)
async def analyze_10k(request: MultimodalRequest):
    """Dedicated endpoint for 10-K document analysis"""
    request.task = "10k"
    return await analyze_multimodal(request)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port)