#!/bin/bash

echo "Starting NexaGen backend deployment..."
echo "Current working directory: $(pwd)"
echo "Files in directory: $(ls -la)"

# Install dependencies
echo "Installing Python dependencies..."
pip3 install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "Failed to install dependencies"
    exit 1
fi

# Check if uvicorn and gunicorn are installed
echo "Checking installed packages..."
pip3 show uvicorn gunicorn

# Start server
echo "Starting Gunicorn with Uvicorn worker..."
gunicorn -w 4 -k uvicorn.workers.UvicornWorker main:app --bind 0.0.0.0:8000
