import os
from typing import Tuple, Optional
import requests
import json
from google.auth import default
from google.auth.transport.requests import Request


class GCPService:
    def __init__(self):
        self.project_id = os.getenv("GCP_PROJECT", "nexagen-ai-ops-platform")
        self.gemini_10k_endpoint = os.getenv("GCP_GEMINI_10K_ENDPOINT")
        self.gemini_cricket_endpoint = os.getenv("GCP_GEMINI_CRICKET_ENDPOINT")
        self.credentials, _ = default()

    def get_gemini_endpoint(self, task: str = "10k"):
        """Get the appropriate Gemini endpoint based on task type"""
        if task.lower() == "cricket":
            return self.gemini_cricket_endpoint
        else:
            return self.gemini_10k_endpoint

    def get_access_token(self):
        if not self.credentials.valid:
            self.credentials.refresh(Request())
        return self.credentials.token

    def analyze_text_gcp(self, text: str, task: str = "10k") -> str:
        try:
            headers = {
                "Authorization": f"Bearer {self.get_access_token()}",
                "Content-Type": "application/json"
            }

            # Customize prompt based on task
            if task.lower() == "cricket":
                prompt = f"Analyze this cricket-related text and provide insights: {text}"
            else:
                prompt = f"Analyze this document text and provide insights: {text}"

            data = {
                "contents": [
                    {
                        "role": "user",
                        "parts": [{"text": prompt}]
                    }
                ]
            }

            # Use the appropriate endpoint based on task
            endpoint = self.get_gemini_endpoint(task)
            if not endpoint:
                return f"No endpoint configured for task: {task}"
            
            url = f"{endpoint}:generateContent"

            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()

            result = response.json()
            return result["candidates"][0]["content"]["parts"][0]["text"]

        except Exception as e:
            return f"GCP Gemini error ({task}): {str(e)}"

    def analyze_multimodal_gcp(self, text: str, image_uri: Optional[str] = None, task: str = "10k") -> Tuple[str, Optional[str]]:
        try:
            headers = {
                "Authorization": f"Bearer {self.get_access_token()}",
                "Content-Type": "application/json"
            }

            # Customize prompt based on task
            if task.lower() == "cricket":
                base_prompt = f"Analyze this cricket-related content: {text}"
                if image_uri:
                    base_prompt += " Also analyze the cricket player image provided."
            else:
                base_prompt = f"Analyze this document content: {text}"
                if image_uri:
                    base_prompt += " Also analyze any figures, charts, or diagrams in the provided image."

            parts = [{"text": base_prompt}]
            if image_uri:
                parts.append({"image_uri": image_uri})

            data = {
                "contents": [
                    {
                        "role": "user",
                        "parts": parts
                    }
                ]
            }

            # Use the appropriate endpoint based on task
            endpoint = self.get_gemini_endpoint(task)
            if not endpoint:
                return f"No endpoint configured for task: {task}", None

            url = f"{endpoint}:generateContent"

            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()

            result = response.json()
            content = result["candidates"][0]["content"]["parts"][0]["text"]

            # Split text and image analysis if both provided
            if image_uri:
                return content, f"Multimodal analysis included for {task} task"
            else:
                return content, None

        except Exception as e:
            return f"GCP error ({task}): {str(e)}", None

    def analyze_cricket_player(self, text: str, image_uri: Optional[str] = None) -> Tuple[str, Optional[str]]:
        """Specific method for cricket player analysis"""
        return self.analyze_multimodal_gcp(text, image_uri, task="cricket")

    def analyze_10k_document(self, text: str, image_uri: Optional[str] = None) -> Tuple[str, Optional[str]]:
        """Specific method for 10-K document analysis"""
        return self.analyze_multimodal_gcp(text, image_uri, task="10k")


# Global instance
gcp_service = GCPService()


def analyze_text_gcp(text: str, task: str = "10k") -> str:
    return gcp_service.analyze_text_gcp(text, task)


def analyze_multimodal_gcp(text: str, image_uri: Optional[str] = None, task: str = "10k") -> Tuple[str, Optional[str]]:
    return gcp_service.analyze_multimodal_gcp(text, image_uri, task)


def analyze_cricket_player_gcp(text: str, image_uri: Optional[str] = None) -> Tuple[str, Optional[str]]:
    """Convenience function for cricket player analysis"""
    return gcp_service.analyze_cricket_player(text, image_uri)


def analyze_10k_document_gcp(text: str, image_uri: Optional[str] = None) -> Tuple[str, Optional[str]]:
    """Convenience function for 10-K document analysis"""
    return gcp_service.analyze_10k_document(text, image_uri)