#!/usr/bin/env python3
import os
import sys
import subprocess

# Add current directory to Python path
sys.path.insert(0, os.path.dirname(__file__))

# Start the FastAPI application
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    subprocess.run([
        "uvicorn", 
        "main:app",
        "--host", "0.0.0.0",
        "--port", str(port)
    ])
