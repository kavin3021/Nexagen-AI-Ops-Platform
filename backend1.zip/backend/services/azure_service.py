
import os
from typing import Tuple, Optional
import requests
import json

class AzureService:
    def __init__(self):
        self.openai_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        self.openai_key = os.getenv("AZURE_OPENAI_KEY")
        self.cv_endpoint = os.getenv("AZURE_CV_ENDPOINT")
        self.cv_key = os.getenv("AZURE_CV_KEY", self.openai_key)

    def analyze_text(self, text: str) -> str:
        if not self.openai_endpoint or not self.openai_key:
            return "Azure OpenAI not configured"

        try:
            headers = {
                "Content-Type": "application/json",
                "api-key": self.openai_key
            }

            data = {
                "messages": [
                    {"role": "system", "content": "You are an expert document analyst."},
                    {"role": "user", "content": f"Analyze this text and provide key insights: {text}"}
                ],
                "max_tokens": 500,
                "temperature": 0.3
            }

            # Assuming GPT-4 deployment name is "gpt-4"
            url = f"{self.openai_endpoint}/openai/deployments/gpt-4/chat/completions?api-version=2024-02-15-preview"

            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()

            result = response.json()
            return result["choices"][0]["message"]["content"]

        except Exception as e:
            return f"Azure OpenAI error: {str(e)}"

    def analyze_image(self, image_uri: str) -> str:
        if not self.cv_endpoint or not self.cv_key:
            return "Azure Computer Vision not configured"

        try:
            headers = {
                "Ocp-Apim-Subscription-Key": self.cv_key,
                "Content-Type": "application/json"
            }

            data = {"url": image_uri}

            url = f"{self.cv_endpoint}/vision/v3.2/analyze?visualFeatures=Categories,Description,Objects"

            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()

            result = response.json()
            description = result.get("description", {}).get("captions", [{}])[0].get("text", "No description available")

            return description

        except Exception as e:
            return f"Azure Vision error: {str(e)}"

    def analyze_multimodal(self, text: str, image_uri: Optional[str] = None) -> Tuple[str, Optional[str]]:
        text_result = self.analyze_text(text)
        image_result = self.analyze_image(image_uri) if image_uri else None

        return text_result, image_result

# Global instance
azure_service = AzureService()

def analyze_text_azure(text: str) -> str:
    return azure_service.analyze_text(text)

def analyze_multimodal_azure(text: str, image_uri: Optional[str] = None) -> Tuple[str, Optional[str]]:
    return azure_service.analyze_multimodal(text, image_uri)
